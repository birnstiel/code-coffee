#------------------------------------------------------------------------------
# example_07.py
#
# who       when        what
# --------  ----------  -------------------------------------------------------
# mwegner   2016-05-08  Created.
#
# Python/C demo, step 7: Encapsulation of C/C++ pointers in Python objects.
#------------------------------------------------------------------------------

# import modules
from example_07 import * # the extension module
from sys        import * # for 'sys.getrefcount'

# create the Orion belt as a number of encapsulated (C++) 'star' objects
try:
    zetaOri    = create_star("Alnitak", 85.189708, -1.942583, 3)
    epsilonOri = create_star("Alnilam", 84.053375, -1.201917)
    deltaOri   = create_star("Mintaka", 83.001667, -0.299083, 4)
except ValueError as e:
    print("ERROR:", e)

# print coordinates
print_star(zetaOri)
print_star(epsilonOri)
print_star(deltaOri)

# check reference counters (1 higher than expected due to 'getrefcount' args)
print("refcount(deltaOri)   =", getrefcount(deltaOri))
print("refcount(epsilonOri) =", getrefcount(epsilonOri))
print("refcount(zetaOri)    =", getrefcount(zetaOri))

# calculate and print distances
d1 = distance(zetaOri, epsilonOri)
d2 = distance(epsilonOri, deltaOri)
print("Alnitak <-- %.3f deg --> Alnilam <-- %.3f deg --> Mintaka" % (d1, d2))
      
# let Alnilam (> 30 M_sun) explode and check for remnants...
del epsilonOri # delete (capsule) object
try:
    print("refcount(epsilonOri) =", getrefcount(epsilonOri))
except NameError as e:
    print("ERROR:", e);
