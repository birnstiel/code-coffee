#------------------------------------------------------------------------------
# example_01.py
#
# who       when        what
# --------  ----------  -------------------------------------------------------
# mwegner   2016-05-08  Created.
#
# Python/C demo, step 1: A simple "Hello, world!".
#------------------------------------------------------------------------------

# import extension module exactly as if it were implemented in Python itself
from example_01 import *

# a simple function, implemented in the extension module
say_hello()
