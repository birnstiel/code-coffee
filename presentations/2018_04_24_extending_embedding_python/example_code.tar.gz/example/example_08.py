#------------------------------------------------------------------------------
# example_08.py
#
# who       when        what
# --------  ----------  -------------------------------------------------------
# mwegner   2016-05-08  Created.
#
# Python/C demo, step 8: A custom Python (class) type, implemented in C.
#------------------------------------------------------------------------------

# import modules
from example_08 import * # the extension module
from sys        import * # for 'sys.getrefcount'
from math       import * # for trigonometric functions

# Calculate the (great-circle) distance between 2 stars on sky.
def distance(s1, s2):
    # retrieve values, convert deg -> rad
    alpha1 = pi/180.0*s1.right_asc
    delta1 = pi/180.0*s1.declination
    alpha2 = pi/180.0*s2.right_asc
    delta2 = pi/180.0*s2.declination
    
    # apply haversine formula to avoid rounding errors
    half_diff_alpha = (alpha2 - alpha1)/2.0
    half_diff_delta = (delta2 - delta1)/2.0
    sin2alpha       = sin(half_diff_alpha)*sin(half_diff_alpha)
    sin2delta       = sin(half_diff_delta)*sin(half_diff_delta)
    d = 2*asin(sqrt(sin2delta + cos(delta1)*cos(delta2)*sin2alpha))

    # return distance in degrees
    return 180.0*d/pi

# create the Orion belt again, now from custom Python 'Star' objects
try:
    zetaOri    = Star("Alnitak", ra = 85.189708, dec = -1.942583, mult = 3)
    epsilonOri = Star("Alnilam", ra = 84.053375, dec = -1.201917)
    deltaOri   = Star("Mintaka", ra = 83.001667, dec = -0.299083, mult = 4)
except ValueError as e:
    print("ERROR:", e)

# print coordinates
zetaOri.print()
epsilonOri.print()
deltaOri.print()

# calculate and print distances (from left to right)
d1 = distance(zetaOri, epsilonOri)
d2 = distance(epsilonOri, deltaOri)
print("Alnitak <-- %.3f deg --> Alnilam <-- %.3f deg --> Mintaka" % (d1, d2))
