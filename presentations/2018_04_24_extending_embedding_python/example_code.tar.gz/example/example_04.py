#------------------------------------------------------------------------------
# example_04.py
#
# who       when        what
# --------  ----------  -------------------------------------------------------
# mwegner   2016-05-08  Created.
#
# Python/C demo, step 4: A simple "Hello, <anybody>!" with function
# parameter(s), returning the message string to Python and throwing an
# exception for missing arguments.
#------------------------------------------------------------------------------

# import extension module
from example_04 import *

# catch possible exceptions thrown in extension module
try:
    msg = say_hello("USM")
    print(msg)
    msg = say_hello("")
    print(msg)
except ValueError as e:
    print("ERROR:", e)
