#------------------------------------------------------------------------------
# example_06.py
#
# who       when        what
# --------  ----------  -------------------------------------------------------
# mwegner   2016-05-08  Created.
#
# Python/C demo, step 6: Keyword parameters in an extension function.
#------------------------------------------------------------------------------

# import extension module
from example_06 import *

# print name, coordinates, and multiplicity for the stars of the Orion belt
try:
    print_star(name = "Alnitak", ra = 85.189708, dec = -1.942583, mult = 3)
    print_star(ra = 84.053375, dec = -1.201917, name = "Alnilam")
    print_star("Mintaka", mult = 4, ra = 83.001667, dec = -0.299083)
except ValueError as e:
    print("ERROR:", e)
