#------------------------------------------------------------------------------
# example_03.py
#
# who       when        what
# --------  ----------  -------------------------------------------------------
# mwegner   2016-05-08  Created.
#
# Python/C demo, step 3: A simple "Hello, <anybody>!" with function
# parameter(s) and returning the message string to Python.
#------------------------------------------------------------------------------

# import extension module exactly as if it were implemented in Python itself
from example_03 import *

# call function in extension module and process the return value
msg = say_hello("USM")
print(msg)
