#------------------------------------------------------------------------------
# example_02.py
#
# who       when        what
# --------  ----------  -------------------------------------------------------
# mwegner   2016-05-08  Created.
#
# Python/C demo, step 2: A simple "Hello, <anybody>!" with function
# parameter(s).
#------------------------------------------------------------------------------

# import extension module exactly as if it were implemented in Python itself
from example_02 import *

# a simple function with a single argument, implemented in the extension module
say_hello("USM")
