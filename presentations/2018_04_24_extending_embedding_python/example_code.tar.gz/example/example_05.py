#------------------------------------------------------------------------------
# example_05.py
#
# who       when        what
# --------  ----------  -------------------------------------------------------
# mwegner   2016-05-08  Created.
#
# Python/C demo, step 5: Different types of position parameters in an extension
# function (here: stellar parameters).
#------------------------------------------------------------------------------

# import extension module
from example_05 import *

# print name, coordinates, and multiplicity for the stars of the Orion belt
try:
    print_star("Alnitak", (85.189708, -1.942583), 3)
    print_star("Alnilam", (84.053375, -1.201917))
    print_star("Mintaka", (83.001667, -0.299083), 4)
except ValueError as e:
    print("ERROR:", e)
