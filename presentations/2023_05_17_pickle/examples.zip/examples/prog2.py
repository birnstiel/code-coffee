import pickle

fname = "thestate.pickle"

with open(fname,'rb') as f:
    x = pickle.load(f)

print(x)
