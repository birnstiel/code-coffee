import pickle
import numpy as np

fname = "thestate2.pickle"

x = 11
L = ["a", 2.31]
q = np.linspace(1,2,5)

with open(fname,'wb') as f:
    pickle.dump( (x,L,q) , f)

################
    
with open(fname,'rb') as f:
    A = pickle.load(f)

print(A)

