import pickle

fname = "thestate.pickle"

x = 11

with open(fname,'wb') as f:
    pickle.dump(x, f)

print(x)
