import time
import numpy as np

# storage for results
class results:
    def __init__(self):
        self._store = []

    def add(self,x):
        self._store.append(x)

    def print(self):
        print(self._store)


rng = np.random.default_rng(12345)
res = results()

for i in range(5):
    # do something
    x = rng.random()
    time.sleep(1)
    res.add(x)

    res.print()

print("final result:")
res.print()
