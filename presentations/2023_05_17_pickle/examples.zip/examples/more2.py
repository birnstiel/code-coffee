import pickle
import numpy as np
from scipy.spatial import KDTree

fname = "thestate3.pickle"

N = 10**4
rng = np.random.default_rng(12345)
pts = rng.uniform(0,1, (N,3) )
tree = KDTree(pts)


with open(fname,'wb') as f:
    pickle.dump( tree , f)

################

with open(fname,'rb') as f:
    A = pickle.load(f)

pt = [0.5,0.5,0.5]

print( A.query(pt,k=3) )

