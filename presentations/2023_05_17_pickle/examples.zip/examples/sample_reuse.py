import pickle
import time
import numpy as np

####
# inspect pickle on the command line
# python -m pickle state.pickle

def save_state(fname, *args):
    with open(fname,'wb') as f:
        pickle.dump(args, f)


def load_state(fname, *args):
    try:
        f = open(fname,'rb')
    except IOError:
        # if no state was saved yet
        S = args
    else:
        # load state
        S = pickle.load(f)
        # simple versioning
        # do not use if args[0]>=S[0]
        if args[0] >= S[0]:
            S = args
        f.close()
    return S


class results:
    def __init__(self):
        self._store = []

    def add(self,x):
        self._store.append(x)

    def print(self):
        print(self._store)


###
rng = np.random.default_rng(12345)
fname = "reuse.pickle"
res = results()

N = 5
istate = 0
while istate < N:
    #istate,res = load_state(fname, istate,res)
    istate,res,rng = load_state(fname, istate,res,rng)
    # we are done
    if istate >= N:
        break
    
    # do something
    x = rng.random()
    time.sleep(1)
    res.add(x)

    # save 
    istate += 1
    #save_state(fname, istate,res)
    save_state(fname, istate,res,rng)
    
    res.print()


print("final result:")
res.print()
