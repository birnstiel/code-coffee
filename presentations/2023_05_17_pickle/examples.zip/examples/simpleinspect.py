import numpy as np
from scipy.spatial import KDTree
import inspect

# 
class results:
    def __init__(self):
        self._store = []

    def add(self,x):
        self._store.append(x)

    def print(self):
        print(self._store)

res = results()
res.add(111)
l = inspect.getmembers(res)
print(l)


#
N = 10**4
rng = np.random.default_rng(12345)
pts = rng.uniform(0,1, (N,3) )
tree = KDTree(pts)

#print(type(tree))
#l = inspect.getmembers(tree)
#print(l)
