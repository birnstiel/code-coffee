class bare:
    pass

o = bare()

o.x = 1

print(o.x)
