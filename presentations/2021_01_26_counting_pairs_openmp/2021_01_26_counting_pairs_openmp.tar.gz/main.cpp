#include <iostream>
#include <cmath>
#include <stdexcept>
#include <vector>
#include <algorithm>
#include <random>

using namespace std;


// define/overload the reduction operator + for  vector<int> (and vector<double>)
//  transform: every call to + reduction iterates through the whole vector using transform
//  initializer: all private variables/vectors are initialized with 0

#pragma omp declare reduction( + : vector<int> : \
  transform(omp_in.begin(),omp_in.end(),omp_out.begin(),omp_out.begin(), plus<int>())) \
  initializer (omp_priv(omp_orig.size(),0))

#pragma omp declare reduction( + : vector<double> :			\
  transform(omp_in.begin(),omp_in.end(),omp_out.begin(),omp_out.begin(), plus<double>())) \
  initializer (omp_priv(omp_orig.size(),0.0))


// Euclidean distance
double dist(double x1, double y1, double z1,
	    double x2, double y2, double z2) {
  return sqrt(pow(x1-x2,2.)+pow(y1-y2,2.)+pow(z1-z2,2.));
}


// x,y,z in one matrix dat row major
//  x_1 y_1 z_1
//  .....
// rad copied
void dd(double* dat, size_t nrow, size_t ncol,
	vector<double>& r, vector<int>& npairs ) {

  double xi,yi,zi;
  // loop over points i
  for(size_t i=0; i<nrow; ++i) {
    xi = dat[i*ncol + 0];
    yi = dat[i*ncol + 1];
    zi = dat[i*ncol + 2];

    // reduction: vector  npairs  are added in the threads 
    //    see overload/declare + for vectors above
#pragma omp parallel for reduction(+:npairs)
    // loop over other points j
    for(size_t j=i+1; j<nrow; ++j) {
      double xj = dat[j*ncol + 0];
      double yj = dat[j*ncol + 1];
      double zj = dat[j*ncol + 2];
      double d = dist(xi,yi,zi, xj,yj,zj);
      // search and add up, if d too large discard
      if (d < r.back()){
	// binary search in the vector of radii r  -- ToDo: check interpolation search
	vector<double>::iterator it = lower_bound(r.begin(), r.end(), d);
	int irad = it - r.begin() - 1; // index = position - 1

	npairs[irad] += 1;
      }
    } // end loop over other points j
    // end omp parallel
    
  } // end loop over points i

  return;
}

///////////////////////

int main() 
{

  // generate poisson distributed points
  mt19937_64 mygen;
  uniform_real_distribution<double> unif(0.0, 1.0);
  int nrow=10000;
  int ncol=3;
  double* pts = new double[nrow*ncol];
  for (int i=0; i<nrow; ++i) {
    for (int j=0; j<ncol; ++j) {
      pts[i*ncol + j] = unif(mygen);
    }  
  }
  
  // initialize radii
  int nint = 10;
  vector<double> r(nint+1, 0.0);
  r[0] = 0; r[nint] = 0.1;
  double h = (r[nint]-r[0])/nint;
  for (int i=1; i<r.size(); ++i) {
    r[i] = r[i-1] + h;
  }
  // initialize npairs
  vector<int> npairs(nint, 0);

  
  // call dd
  dd(pts,nrow,ncol,  r, npairs);

  
  // out
  for (int i=0; i< npairs.size(); ++i) {
    cout << r[i] << " " << r[i+1] << " " << npairs[i] << endl;
  }

  return 0;
}
