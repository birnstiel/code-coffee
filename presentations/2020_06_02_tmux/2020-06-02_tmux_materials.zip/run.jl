for i = 1:1000
    println(i)
    sleep(1)
end
