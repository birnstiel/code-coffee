for i = 1:5
    println(i)
    sleep(1)
end
