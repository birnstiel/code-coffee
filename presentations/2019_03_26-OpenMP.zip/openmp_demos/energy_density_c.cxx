#include<iostream>
#include <vector>
#include<cstdlib>
#include<cmath>
#include<omp.h>

using namespace std;

const double pi         = 3.1415926535897932;
const double clight     = 29979245800.0;
const double parsec     = 3.08567758149137E+18;
const double sboltzmann = 5.670367E-5;
const double sunr       = 6.96342E+10;


class TStar
{
public:
  TStar(double x_max, double y_max, double z_max,
        double r_max, double teff_max, double cs)
  {
    x         = 0.; //(double) (rand()/RAND_MAX)*x_max;
    y         = 0.; //(double) (rand()/RAND_MAX)*z_max;
    z         = 0.; //(double) (rand()/RAND_MAX)*z_max;
    r         = 10.; // (((double) (rand()/RAND_MAX)*r_max*sunr;
    teff      = 30000.; //(double) (rand()/RAND_MAX)*teff_max;
    cellsize  = cs;
    luminosity= 4*pi*pow(teff,4)*pow((r*sunr),2)*sboltzmann;
  };

 
  double energydensity(int cell_x, int cell_y, int cell_z)
  {
    return luminosity/
      (clight*4*pi*(parsec*cellsize)*(parsec*cellsize)*
      (
       ((double)cell_x+0.5-x)*((double)cell_x+0.5-x)+
       ((double)cell_y+0.5-y)*((double)cell_y+0.5-y)+
       ((double)cell_z+0.5-z)*((double)cell_z+0.5-z)
       )
       );
  }

private:
  
  double x;          // x-position 
  double y;          // y-postition
  double z;          // z_position
  double r;          // Radius in Rsun
  double teff;       // effective temperature
  double cellsize;   // size of a cell in parsec
  double luminosity; // luminosity in erg s^-1
};


int main(void)
{

  int    xsize,ysize,zsize;
  int    num_stars;
  double cellsize;
  int    parallel_method;

  double checksum=0.0;
  
  
  cin>>xsize>>ysize>>zsize>>num_stars>>cellsize>>parallel_method;
  
  vector<vector <vector <double> > > space;
  vector<TStar> cluster;
  
  // some initialization stuff
  for (int counter=1; counter<=num_stars; counter++)
    {
      cluster.push_back(TStar(1.0*xsize,1.0*ysize,1.0*zsize,20.,50000., cellsize));
    }

  space.resize(xsize);
  for (int xcounter=0;xcounter<xsize; xcounter++)
    {
      space[xcounter].resize(ysize);
      for (int ycounter=0; ycounter<ysize; ycounter++)
        {
          space[xcounter][ycounter].resize(zsize);
          for (int zcounter=0; zcounter<zsize; zcounter++)
            {
              space[xcounter][ycounter][zcounter]=0.0;
            }
        }
    }

  switch(parallel_method)
    {
    case 0:             // no_parallelization at all.
      for (int xcounter=0; xcounter<xsize; xcounter++)
        for (int ycounter=0; ycounter<ysize; ycounter++)
          for (int zcounter=0; zcounter<zsize; zcounter++)
            for (int starcounter=0; starcounter< num_stars; starcounter++)
              {
                space[xcounter][ycounter][zcounter]+=
                  cluster[starcounter].energydensity(xcounter,ycounter,zcounter);
              }
      break;

    case 1:            // parallelize x-counter loop (outermost loop)
#pragma omp parallel for 
      for (int xcounter=0; xcounter<xsize; xcounter++)
        for (int ycounter=0; ycounter<ysize; ycounter++)
          for (int zcounter=0; zcounter<zsize; zcounter++)
            for (int starcounter=0; starcounter< num_stars; starcounter++)
              {
                space[xcounter][ycounter][zcounter]+=
                  cluster[starcounter].energydensity(xcounter,ycounter,zcounter);
              }
      break;

    case 2:            // parallelize y-counter loop 
                       // ("intermediate" spatial loop)
      for (int xcounter=0; xcounter<xsize; xcounter++)
#pragma omp parallel for
        for (int ycounter=0; ycounter<ysize; ycounter++)
          for (int zcounter=0; zcounter<zsize; zcounter++)
            for (int starcounter=0; starcounter< num_stars; starcounter++)
              {
                space[xcounter][ycounter][zcounter]+=
                  cluster[starcounter].energydensity(xcounter,ycounter,zcounter);
              }
      break;

    case 3:            // parallelize z-counter loop
                       // (innermost "spatial" loop)
      for (int xcounter=0; xcounter<xsize; xcounter++)
        for (int ycounter=0; ycounter<ysize; ycounter++)
#pragma omp parallel for
            for (int zcounter=0; zcounter<zsize; zcounter++)
            for (int starcounter=0; starcounter< num_stars; starcounter++)
              {
                space[xcounter][ycounter][zcounter]+=
                  cluster[starcounter].energydensity(xcounter,ycounter,zcounter);
              }
      break;

    case 4:            // parallelize star-counter loop
      for (int xcounter=0; xcounter<xsize; xcounter++)
        for (int ycounter=0; ycounter<ysize; ycounter++)
          for (int zcounter=0; zcounter<zsize; zcounter++)
#pragma omp parallel for
            for (int starcounter=0; starcounter< num_stars; starcounter++)
                {
#pragma omp critical  // required to aviod race conditions
                  {
                    space[xcounter][ycounter][zcounter]+=
                      cluster[starcounter].energydensity
                      (xcounter,ycounter,zcounter);
           }
                 }
      break;

    case 5:            // use _one_ loop over the cells and map
                       // it to the coordinates
#pragma omp parallel for
      for (int cellcounter=0; cellcounter<xsize*ysize*zsize; cellcounter++)
        {
          int xcounter, ycounter, zcounter;
          xcounter=cellcounter/(ysize*zsize);
          ycounter=(cellcounter%(ysize*zsize))/zsize;
          zcounter=cellcounter%zsize;
          for (int starcounter=0; starcounter< num_stars; starcounter++)
            {
              space[xcounter][ycounter][zcounter]+=
                cluster[starcounter].energydensity(xcounter,ycounter,zcounter);
            }     
        }
      break;
    }

// checksum
  for (int xcounter=0; xcounter<xsize; xcounter++)
   for (int ycounter=0; ycounter<ysize; ycounter++)
     for (int zcounter=0; zcounter<zsize; zcounter++)
     checksum+=space[xcounter][ycounter][zcounter];

 cout<<"checksum (C++) :"<<checksum<<endl;

  exit(EXIT_SUCCESS);
}

