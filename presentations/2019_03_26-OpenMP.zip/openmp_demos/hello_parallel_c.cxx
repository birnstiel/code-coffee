/* 
  This example program demostrates the functions omp_get_num_threads() and
  omp_get_thread_num(), as well as the fact that there is no defined order
  between the threads.
  Furthermore, it shows how to avoid race conditions. 
*/ 


#include <iostream>
#include <cstdlib>
#include <omp.h>

using namespace std;

  int some_global_value=42;  
  int factorial=1;


int main(void)
{

#pragma omp parallel
  {
    if (omp_get_thread_num()==0)
      {
	cout<<"In total there are "<<omp_get_num_threads()<<" Threads."<<endl;
      } 
  }

#pragma omp parallel
  {    
#pragma omp critical      // The next statement will only be executed by 
                          // one thread at the same time.
                          // So race conditions can be avoided.
                          // To trigger race conditions, you can
                          // comment out the critical (and atomic) pragmas
    cout<<"Hello, here is thread #"<<omp_get_thread_num()<<"."<< endl;
  }

//Compute the factorial of the number of threads:
#pragma omp parallel
  {
    int factor=omp_get_thread_num()+1;


#pragma omp atomic        // The code block will only be executed by 
                          // on thread at the same time.
                          // In contrast to omp critical, omp atomic
                          // only allows for single simple statements
                          // like the one below.
    factorial*=factor;
  }  
  cout<<endl;
  cout<<"Result for !(number of threads): "<<factorial<<endl;
  cout <<endl;
#pragma omp parallel
  {
#pragma omp critical     

    {
      cout<<"It was nice to meet you."<<endl;
      cout<<"Goodbye, yours thread #"<<omp_get_thread_num()<<"."<<endl;
      cout<<endl;
    }
  }

  // The "private" specifier will create new local variables unrelated to the
  // global variable of the same name
#pragma omp parallel private(some_global_value)
  {
    #pragma omp critical
    {
      cout<<"Thread # "<<omp_get_thread_num()<<" private some_global_value = "
	               <<some_global_value<<endl;
    }
  }
  cout<<endl;

  // The "firstprivate" specifier will copy the global varibale  
  // some_global_variable to the initial values of the
  // thread-private variables  
// #pragma omp parallel firstprivate(some_global_value)
//   {
//     #pragma omp critical
//     {
//       cout<<"Thread # "<<omp_get_thread_num()
// 	  <<" firstprivate some_global_value = "
// 	  <<some_global_value<<endl;
//     }
//   }
  cout<<endl;

  
  exit(EXIT_SUCCESS);
}

  
