#include <iostream>
#include <ctime>
#include <cmath>
#include <cstdlib>
#include <omp.h>

using namespace std;

typedef int myint;

int main(void)
{
  myint large_number=0;
  myint primes_below=0;

#pragma omp parallel
  {
    if (omp_get_thread_num() == 0)
      cout<<"Prime number calculator (C++) using "<<omp_get_num_threads()
          <<" threads."<<endl;
  }
  cout<<"You want to know the number of primes less or equal which number ?"
      <<endl;
  cin>>large_number;

  //  omp_set_schedule(omp_static,1);


  // The reduction clause (+:) means that at the end of the
  // parallel region the local primes_below variables are added up

  
#pragma omp parallel for reduction(+:primes_below)
  for (myint le_number=3; le_number <= large_number; le_number+=2)
  {
    myint testcounter, test_max;
    bool is_prime;
    test_max=(myint) round(sqrt(1.0*le_number));
    is_prime=true;
    for (testcounter=2; testcounter<=test_max; testcounter++)
      {
	if (le_number%testcounter == 0ll)
	  {
	    is_prime=false;
	    break;
	  }
      }
    if (is_prime)
      primes_below++;
  }
  primes_below++;          // because 2 is prime, but not covered above
  cout<< "Number of primes less than or equal to "<<large_number<<" : " 
      <<primes_below<<endl;
  return (EXIT_SUCCESS);
}

